In this assignment I've made pretty distinctive classes for proper organization.

There are two major classes:
1. Admin
2. Visitor

Admin Class:
	Admin class has it's various options which leads to various classes.
Visitor Class:
	Visitor class has it's various options which leads to various classes.

In the entire assignment there are various databases.
	Each database has a specific function.
	I made databases as a data storage point. Also these databases has static functions which utilizes the data in the database and does all the required functionalities.
	All databases has ArrayLists which stores the data and peocesses them.
	All the databases stores specific kinds of data for which other classes have been made.For ex, Attraction class, Ticket class etc.

Finally I've connected all these databases to Admin class and Visitor class to get a functional application interface.

This is the framework of my code and except this only basic algorithms are executed throughout to get various functionalities achieved.