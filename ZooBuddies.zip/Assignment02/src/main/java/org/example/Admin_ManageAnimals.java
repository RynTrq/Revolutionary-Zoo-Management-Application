import java.util.Scanner;

public class Admin_ManageAnimals {
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    static String BLUE= "\u001B[34m";

    static Scanner scan = new Scanner(System.in);
    protected static void manageAnimals() {
        while(true) {
            System.out.println(BLUE + "\nManage Animals" + RESET);
            System.out.println(BLUE + "\n1. Add Animal.\n" +
                    "2. View Animals.\n" +
                    "3. Modify Animal.\n" +
                    "4. Remove Animal.\n" +
                    "5. Exit.\n" + RESET);
            System.out.print("Enter your choice: ");
            int givenInput = Integer.parseInt(scan.nextLine());
            if (givenInput == 5) {
                break;
            }else if(givenInput == 1){
                addAnimal();
            }else if(givenInput == 2){
                viewAnimals();
            }else if(givenInput == 3){
                modifyAnimal();
            }else if(givenInput == 4){
                removeAnimal();
            }else{
                System.out.println(RED+"ERROR!: Invalid input!"+RESET);
            }
        }
    }


    private static void addAnimal(){
        System.out.print("\nEnter Animal name: ");
        String name = scan.nextLine();
        System.out.print("Enter Animal sound: ");
        String sound = scan.nextLine();
        System.out.print("Enter price of Animal(in Rs): ");
        int price = Integer.parseInt(scan.nextLine());
            int ID = Database_Animals.addToListOfAnimals(name,sound,price);
            if(ID!=-1) {
                System.out.println("Animal added successfully\n" +
                        "Animal Code - " + ID);
            }
    }

    private static void viewAnimals(){
        Database_Animals.viewAnimals();
    }
    private static void modifyAnimal(){
        System.out.println("\nModify Animal.");
        System.out.print("Enter the code of animal you want to modify: ");
        int inputCode = Integer.parseInt(scan.nextLine());

        Database_Animals.modifyAnimal(inputCode);
    }
    private static void removeAnimal(){
        System.out.println("Remove Animal:");
        System.out.print("Enter Code of Animal you want to remove: ");
        int inputCode = Integer.parseInt(scan.nextLine());
        Database_Animals.removeAnimal(inputCode);
    }
}
