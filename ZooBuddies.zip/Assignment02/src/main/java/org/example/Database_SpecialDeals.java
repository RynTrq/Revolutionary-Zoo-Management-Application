import java.util.ArrayList;
import java.util.Scanner;

public class Database_SpecialDeals {
    private static ArrayList<SpecialDeals> listOfSpecialDeals = new ArrayList<>();
    static Scanner scan = new Scanner(System.in);
    protected static void addSpecialDeal(){
        System.out.println("\nAdd Special Deal:");
        System.out.print("Enter the number of tickets to be purchased to get special deal: ");
        int noOfPurchases = Integer.parseInt(scan.nextLine());
        System.out.print("Enter description: ");
        String description = scan.nextLine();
        System.out.print("Enter the percentage off: ");
        int percentageOff = Integer.parseInt(scan.nextLine());
        if(findSpecialDeal(noOfPurchases)==null){
            listOfSpecialDeals.add(new SpecialDeals(description,noOfPurchases,percentageOff));
            System.out.println("Special Deal added!");
        }else{
            System.out.println("There's already a special deal on "+noOfPurchases+" purchases.");
        }
    }

    protected static void removeSpecialDeal(){
        System.out.println("\nRemove Special Deal:");
        System.out.print("Enter the number of tickets for special deal to be removed: ");
        int noOfPurchases = Integer.parseInt(scan.nextLine());
        SpecialDeals temp = findSpecialDeal(noOfPurchases);
        if(temp==null){
            System.out.println("There is no special deal on "+noOfPurchases+" to be removed.");
        }else{
            listOfSpecialDeals.remove(temp);
            System.out.println("Special deal for "+noOfPurchases+" purchases have been removed.");
        }
    }

    protected static SpecialDeals findSpecialDeal(int numberOfTickets){
        for(SpecialDeals itr:listOfSpecialDeals){
            if(itr.getCountOfAttractions()==numberOfTickets){
                return itr;
            }
        }
        return null;
    }
    protected static void viewSpecialDeals(){
        System.out.println("\nView special deals:");
        if(listOfSpecialDeals.isEmpty()){
            System.out.println("Sorry there are no special deals for now.");
        }else {
            for (SpecialDeals itr : listOfSpecialDeals) {
                System.out.println("No of purchases: " + itr.getCountOfAttractions() + "\n" +
                        "Details of deal: " + itr.getDescription()+"\n" +
                        "Percentage off: "+itr.getPercentageOff());
                System.out.println("------------------------------");
            }
        }
    }

    protected static SpecialDeals maxOff(int count){
        if(listOfSpecialDeals.isEmpty()){
            return null;
        }else{
            SpecialDeals temp = new SpecialDeals("N/A",0,0);
            for(SpecialDeals itr:listOfSpecialDeals){
                if(itr.getCountOfAttractions()<count && itr.getPercentageOff() > temp.getPercentageOff()){
                    temp = itr;
                }
            }
            return temp;
        }
    }
}
