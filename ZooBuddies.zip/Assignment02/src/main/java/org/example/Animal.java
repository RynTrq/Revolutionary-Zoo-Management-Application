public class Animal {
    private String name;
    private String description;
    private String sound;
    private int price;
    private int code;
    protected Animal(String name,String sound,int price,int code){
        this.name = name;
        this.sound = sound;
        this.price = price;
        this.code = code;
    }

    protected String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    protected String getDescription() {
        return description;
    }

    protected void setDescription(String description) {
        this.description = description;
    }

    protected int getPrice() {
        return price;
    }

    protected void setPrice(int price) {
        this.price = price;
    }

    protected int getCode() {
        return code;
    }

    public String getSound() {
        return sound;
    }

    public void setSound(String sound) {
        this.sound = sound;
    }

    protected void setCode(int code) {
        this.code = code;
    }
}
