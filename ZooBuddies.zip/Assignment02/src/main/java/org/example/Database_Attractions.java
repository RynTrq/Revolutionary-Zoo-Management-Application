import org.w3c.dom.Attr;

import java.util.ArrayList;
import java.util.Scanner;

public class Database_Attractions {
    static Scanner scan = new Scanner(System.in);
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String PURPLE = "\u001B[35m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    private static ArrayList<Attraction> listOfAttractions = new ArrayList<>();

    //Adding Attraction.
    static int AttractionIDTrack = 100;
    protected static int addToListOfAttractions(String name, String description, int price){
        int srch = searchForAttractoin(name,description);
        if(srch==0){
            System.out.println(RED+"\nError!: The given name and description of the Attraction already exists."+RESET);
            return -1;
        }else if(srch==1){
            System.out.println(RED+"\nError!: The given name of the Attraction already exists."+RESET);
            return -1;
        }
        listOfAttractions.add(new Attraction(name,description,price,AttractionIDTrack));
        AttractionIDTrack += 1;
        return AttractionIDTrack - 1;
    }
    private static int searchForAttractoin(String name,String description){
        for(Attraction currentAttraction:listOfAttractions){
            if(currentAttraction.getName().equalsIgnoreCase(name)){
                if(currentAttraction.getDescription().equalsIgnoreCase(description)){
                    return 0;
                }else{
                    return 1;
                }
            }
        }
        return -1;
    }
    //Done with adding attraction.
    //View Attractions.
    protected static void viewAttractions(){
        System.out.println("\nAttractions:");
        if(listOfAttractions.isEmpty()){
            System.out.println("There are no attractions as of now.");
        }
        for(Attraction currentAttraction:listOfAttractions){
            System.out.println("Attraction ID: "+currentAttraction.getID());
            System.out.println("Attraction name: "+currentAttraction.getName());
            System.out.println("Attraction description: "+currentAttraction.getDescription());
            System.out.println("Attraction price: "+currentAttraction.getPrice());
            if(currentAttraction.getTimeOfEvent()!=null){
                System.out.println("Attraction time: "+currentAttraction.getTimeOfEvent());
            }else{
                System.out.println("The time of event hasn't been assigned.");
            }
            System.out.println("------------------------------");
        }
    }
    //Done with view Attractions.
    //Modify Attractions.
    protected static void modifyAttraction(int inputID){
        Attraction currentAttraction = findAttraction(inputID);
        if(currentAttraction == null){
            System.out.println(RED+"ERROR!: Given ID doesn't exist."+RESET);
        }else{
            while(true){
                System.out.println("What is it that you wan to modify of "+currentAttraction.getName());
                System.out.println("""
                        1. Name.
                        2. Description.
                        3. Price.
                        4. Time.
                        5. Exit.""");
                System.out.print("Enter your choice: ");
                int givenInput = Integer.parseInt(scan.nextLine());
                if(givenInput == 5){
                    break;
                }else if(givenInput == 1){
                    System.out.print("Enter new name: ");
                    String newName = scan.nextLine();
                    currentAttraction.setName(newName);
                    System.out.println("The name has been updated to "+newName+"!");
                }else if(givenInput == 2){
                    System.out.print("Enter new description: ");
                    String newdes = scan.nextLine();
                    currentAttraction.setDescription(newdes);
                    System.out.println("The description has been updated to "+newdes+"!");
                } else if (givenInput==3) {
                    System.out.print("Enter new Price: ");
                    int newPrice = Integer.parseInt(scan.nextLine());
                    currentAttraction.setPrice(newPrice);
                    System.out.println("The price has been updated to "+newPrice+"!");
                } else if (givenInput == 4) {
                    System.out.print("Enter the time you want to update with: ");
                    String time = scan.nextLine();
                    currentAttraction.setTimeOfEvent(time);
                    System.out.println("The time has been updated to "+time+"!");
                }else{
                    System.out.println(RED+"ERROR!: Invalid input! TRY AGAIN."+RESET);
                }
            }
        }
    }
    protected static Attraction findAttraction(int inputID){
        for(Attraction currentAttraction:listOfAttractions){
            if(currentAttraction.getID()==inputID){
                return currentAttraction;
            }
        }
        return null;
    }
    //Dome with modify attraction.
    //Remove Attraction.
    protected static void removeAttraction(int inputID){
        Attraction currentAttraction = findAttraction(inputID);
        if(currentAttraction == null){
            System.out.println(RED+"ERROR!: Given ID doesn't exist."+RESET);
        }else{
            listOfAttractions.remove(currentAttraction);
            System.out.println("Attraction with ID "+inputID+" successfully removed!");
        }
    }
    //Done with Remove Attractions.
    //Scheduling Event.
    protected static void scheduleEvent(int inputID){
        Attraction currentAttraction = findAttraction(inputID);
        if(currentAttraction == null){
            System.out.println(RED+"ERROR!: Given ID doesn't exist."+RESET);
        }else{
            System.out.println("Enter the time of event you want to schedule to:");
            String time = scan.nextLine();
            currentAttraction.setTimeOfEvent(time);
            System.out.println("The time of "+currentAttraction.getName()+" has been updated to "+time+".");
        }
    }

    protected static void buyTickets(int attractionID, int count, int discountPeercentage){
        int specialDealDiscount;
        SpecialDeals specialDeal = Database_SpecialDeals.maxOff(count);
        if(specialDeal==null){
            specialDealDiscount=0;
        }else{
            specialDealDiscount=specialDeal.getPercentageOff();
            if(specialDealDiscount+discountPeercentage >= 100){
                System.out.println("Because special deal discount and discount code total is exceeding 100%, special deal discount is not applied.");
                specialDealDiscount=0;
            }
        }

        Attraction temp = findAttraction(attractionID);
        if(temp==null){
            System.out.println("The given attraction ID doesn't exist.");
        }else{
            int price = temp.getPrice();
            int totalPrice = price*count ;
            int newBalance = Visitor.currentVisitor.getBalance() - totalPrice + totalPrice*(discountPeercentage/100) + totalPrice*(specialDealDiscount/100) ;
            if(newBalance>=0){
                Visitor.currentVisitor.getListOfTickets().add(new Ticket(count,temp));
                System.out.println("You've successfully bought "+count+"ticket for "+temp.getName()+".");
                Admin.totalRevenue += totalPrice - totalPrice*(discountPeercentage/100) - totalPrice*(specialDealDiscount/100);
                Visitor.currentVisitor.setBalance(newBalance);
                System.out.println("Current Balance - "+newBalance);
            }else{
                System.out.println("You ain't got enough balance to buy "+count+"ticket for "+temp.getName()+".");
            }
        }
    }

    protected static void visitAttraction(int inputID){
        Attraction attractionToVisit = findAttraction(inputID);
        Ticket ticketOfCurrentVisitor = Visitor.currentVisitor.findTicket(attractionToVisit);
        if(attractionToVisit==null){
            System.out.println(RED+"ERROR!: The given ID of attraction doesn't exist."+RESET);
        }else{
            if(Visitor.currentVisitor.getExperience().equalsIgnoreCase("Premium")){
                System.out.println("Welcome to "+attractionToVisit.getName());
                attractionToVisit.setNoOfVisitors(attractionToVisit.getNoOfVisitors()+1);
            }else if(ticketOfCurrentVisitor!=null){
                System.out.println("Welcome to "+attractionToVisit.getName());
                attractionToVisit.setNoOfVisitors(attractionToVisit.getNoOfVisitors()+1);
                Visitor.currentVisitor.listOfTickets.remove(ticketOfCurrentVisitor);
            }else{
                System.out.println("Sorry, neither you are a premium member nor you have a ticket for "+attractionToVisit.getName());
            }
        }
    }

    protected static ArrayList<Attraction> mostPopularAttraction(){
        ArrayList<Attraction> toBeReturned = new ArrayList<>();
        if(listOfAttractions.isEmpty()){
            return null;
        }else{
            Attraction temp = listOfAttractions.get(0);
            for(Attraction itr:listOfAttractions){
                if(itr.getNoOfVisitors()>temp.getNoOfVisitors()){
                    temp = itr;
                }
            }
            for(Attraction itr:listOfAttractions){
                if(itr.getNoOfVisitors()==temp.getNoOfVisitors()){
                    toBeReturned.add(itr);
                }
            }
            return toBeReturned;
        }
    }
}
