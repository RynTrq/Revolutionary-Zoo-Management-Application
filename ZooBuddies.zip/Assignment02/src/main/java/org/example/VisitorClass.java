import java.util.ArrayList;

public class VisitorClass {
    private String name;
    private int age;
    private String phNo;
    private int balance;
    private String Email;
    private String password;
    private String experience;
    protected ArrayList<Ticket> listOfTickets;

    public VisitorClass(String name, int age, String phNo, int balance, String email, String password) {
        this.name = name;
        this.age = age;
        this.phNo = phNo;
        this.balance = balance;
        Email = email;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhNo() {
        return phNo;
    }

    public void setPhNo(String phNo) {
        this.phNo = phNo;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        if(experience.equalsIgnoreCase("Premium") || experience.equalsIgnoreCase("Basic")){
            this.experience = experience;
        }else{
            System.out.println(experience+" is not an available plan for experience.");
        }
    }

    public ArrayList<Ticket> getListOfTickets() {
        return listOfTickets;
    }

    public void setListOfTickets(ArrayList<Ticket> listOfTickets) {
        this.listOfTickets = listOfTickets;
    }

    protected Ticket findTicket(Attraction givenAttraction){
        for(Ticket ticketNow:listOfTickets){
            if(ticketNow.getAttraction()==givenAttraction){
                return ticketNow;
            }
        }
        return null;
    }
}
