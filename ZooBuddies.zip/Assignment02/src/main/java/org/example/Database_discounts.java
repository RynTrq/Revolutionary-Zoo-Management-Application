import java.util.ArrayList;
import java.util.Scanner;

public class Database_discounts {
    private static ArrayList<Discount> listOfDiscounts = new ArrayList<>();
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    static String BLUE= "\u001B[34m";
    static Scanner scan = new Scanner(System.in);
    protected static void addDiscount(){
        System.out.print("\nEnter the code for discount: ");
        String discountCode = scan.nextLine();
        System.out.print("Enter the details for discount: ");
        String details = scan.nextLine();
        System.out.print("Enter the starting age for the discount(enter 0 in case of no starting age): ");
        int startAge = Integer.parseInt(scan.nextLine());
        System.out.print("Enter the ending age for the discount(enter -1 in case of no ending age): ");
        int endAge = Integer.parseInt(scan.nextLine());
        System.out.print("Enter, for what the discount is(membership/ticket):");
        String discountfor = scan.nextLine();
        System.out.print("Enter the percentage of discount to be applied: ");
        int discountPercentage = Integer.parseInt(scan.nextLine());
        if (!(discountPercentage>0 && discountPercentage<=100)){
            System.out.println(RED+"ERROR!: Discount percentage has got to be within 0 to 100."+RESET);
            return;
        }
        if(discountfor.equalsIgnoreCase("membership") || discountfor.equalsIgnoreCase("ticket")) {
            if (findDiscount(discountCode) == null) {
                listOfDiscounts.add(new Discount(discountCode, details, startAge, endAge,discountPercentage));
                System.out.println("Discount with code " + discountCode + " added to available discounts.");
            } else {
                System.out.println(RED + "ERROR!: The discount code " + discountCode + " already exists." + RESET);
            }
        }else{
            System.out.println(RED+"ERROR!: Invalid input for discount type."+RESET);
        }

    }
    protected static Discount findDiscount(String discountCode){
        for(Discount tempDiscount: listOfDiscounts){
            if(tempDiscount.getDiscountCode().equals(discountCode)){
                return tempDiscount;
            }
        }
        return null;
    }

    protected static void removeDiscount(){
        System.out.print("\nEnter the code for discount which you want to remove: ");
        String discountCode = scan.nextLine();
        Discount discountToBeRemoved = findDiscount(discountCode);
        if(discountCode==null){
            System.out.println(RED+"ERROR!: The entered discount code doesn't exist.");
        }else{
            listOfDiscounts.remove(discountToBeRemoved);
            System.out.println("The discount with discount code "+discountCode+" has been removed.");
        }
    }

    protected static void viewDiscounts(){
        System.out.println("\nDiscounts: ");
        if(listOfDiscounts.isEmpty()){
            System.out.println("Sorry, there's no discount as of now.");
        }else{
            for(Discount iter:listOfDiscounts){
                System.out.println("Discount Code: "+iter.getDiscountCode()+"\n" +
                        "Details: "+iter.getDetails()+"\n" +
                        "Discount percentage: "+iter.getDiscountPercentage());
                System.out.println("------------------------------");
            }
        }
    }

    protected static int checkEligibility(String discountCode){
        Discount discountToBeApplied = findDiscount(discountCode);
        int age = Visitor.currentVisitor.getAge();
        if(discountToBeApplied == null){
            return -1;
        }else if((discountToBeApplied.getStartAge() <= age) && (discountToBeApplied.getEndAge() >= age)){
            return 1;
        }else{
            return 0;
        }
    }
}
