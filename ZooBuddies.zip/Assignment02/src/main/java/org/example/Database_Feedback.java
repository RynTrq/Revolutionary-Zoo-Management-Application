import java.util.ArrayList;

public class Database_Feedback {
    private static ArrayList<Feedback> listOfFeedbacks = new ArrayList<>();

    protected static void newFeedback(String name,String content){
        listOfFeedbacks.add(new Feedback(name,content));
        System.out.println("Thank you for your feedback.");
    }

    protected static void viewFeedbacks(){
        if(listOfFeedbacks.isEmpty()){
            System.out.println("No feedback available.");
        }else{
            for(Feedback currentFeedback:listOfFeedbacks){
                System.out.println(currentFeedback.getName()+" says:\n" +
                        currentFeedback.getContent());
                System.out.println("------------------------------");
            }
        }
    }
}
