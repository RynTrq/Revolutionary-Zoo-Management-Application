import java.util.ArrayList;

public class Database_Visitors {
    protected static ArrayList<VisitorClass> listOfVisitors = new ArrayList<>();

    protected static int addVisitor(String name, int age, String phNo, int balance, String Email, String password) {
        int searchResult = searchVisitor(Email, phNo);
        if (searchResult == -1) {
            listOfVisitors.add(new VisitorClass(name, age, phNo, balance, Email, password));
            return -1;
        } else {
            return searchResult;
        }
    }

    private static int searchVisitor(String Email, String phNo) {
        for (VisitorClass currentVisitorClass : listOfVisitors) {
            if (currentVisitorClass.getEmail().equals(Email)) {
                if (currentVisitorClass.getPhNo().equals(phNo)) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if (currentVisitorClass.getPhNo().equals(phNo)) {
                    return 2;
                }
            }
        }
        return -1;
    }

    protected static VisitorClass findVisitor(String Email){
        for(VisitorClass currentVisitorClass:listOfVisitors){
            if(currentVisitorClass.getEmail().equals(Email)){
                return currentVisitorClass;
            }
        }
        return null;
    }

    protected static void buyMembership(VisitorClass currentVisitor,String experience,int DiscountPercentage){
        String currentExperience = currentVisitor.getExperience();
        if(currentExperience!=null && currentExperience.equalsIgnoreCase("Basic")){
            if(currentExperience.equalsIgnoreCase(experience)){
                System.out.println("You already have a Basic experience membership level.");
            }else{
                currentVisitor.setExperience("Premium");
                int newBalance = currentVisitor.getBalance() - Admin.getPremiumPrice() + (Admin.getPremiumPrice())*(DiscountPercentage/100);
                if(newBalance>=0){
                    currentVisitor.setBalance(newBalance);
                    Admin.totalRevenue += Admin.getPremiumPrice() - (Admin.getPremiumPrice())*(DiscountPercentage/100);
                    System.out.println("Membership updated to Premium.");
                    System.out.println("Current Balance - "+currentVisitor.getBalance());
                }else{
                    System.out.println("Sorry you ain't got enough balance to purchase a premium experience level membership.");
                }
            }
        }else if(currentExperience!=null && currentExperience.equalsIgnoreCase("Premium")){
            System.out.println("You already have a premium membership.");
        }else{
            if(experience.equalsIgnoreCase("Basic")){
                int newBalance = currentVisitor.getBalance() - Admin.getBasicPrice() + (Admin.getBasicPrice())*(DiscountPercentage/100);
                if(newBalance>=0){
                    currentVisitor.setExperience("Basic");
                    System.out.println("Basic membership bought.");
                    Admin.totalRevenue += Admin.getBasicPrice() - (Admin.getBasicPrice())*(DiscountPercentage/100);
                    currentVisitor.setBalance(newBalance);
                    System.out.println("Current Balance - "+currentVisitor.getBalance());
                }else{
                    System.out.println("Sorry you ain't got enough balance to purchase a basic experience level membership.");
                }
            }else{
                int newBalance = currentVisitor.getBalance() - Admin.getPremiumPrice() + (Admin.getPremiumPrice())*(DiscountPercentage/100);
                if(newBalance>=0){
                    currentVisitor.setExperience("Premium");
                    System.out.println("Premium membership bought.");
                    Admin.totalRevenue += Admin.getPremiumPrice() - (Admin.getPremiumPrice())*(DiscountPercentage/100);
                    currentVisitor.setBalance(newBalance);
                    System.out.println("Current Balance - "+currentVisitor.getBalance());
                }else{
                    System.out.println("Sorry you ain't got enough balance to purchase a premium experience level membership.");
                }
            }
        }
    }
}
