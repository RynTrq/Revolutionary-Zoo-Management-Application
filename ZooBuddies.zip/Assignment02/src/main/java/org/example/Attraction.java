public class Attraction {
    private String name;
    private String description;
    private String timeOfEvent;
    private int price;
    private int ID;
    private int noOfVisitors;
    protected Attraction(String name,String description,int price,int ID){
        this.name = name;
        this.description = description;
        this.price = price;
        this.ID = ID;
        noOfVisitors = 0;
    }

    public int getNoOfVisitors() {
        return noOfVisitors;
    }

    public void setNoOfVisitors(int noOfVisitors) {
        this.noOfVisitors = noOfVisitors;
    }

    protected String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    protected String getDescription() {
        return description;
    }

    protected void setDescription(String description) {
        this.description = description;
    }

    protected String getTimeOfEvent() {
        return timeOfEvent;
    }

    protected void setTimeOfEvent(String timeOfEvent) {
        this.timeOfEvent = timeOfEvent;
    }

    protected int getPrice() {
        return price;
    }

    protected void setPrice(int price) {
        this.price = price;
    }

    protected int getID() {
        return ID;
    }

    protected void setID(int ID) {
        this.ID = ID;
    }
}
