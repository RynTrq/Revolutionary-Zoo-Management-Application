public class SpecialDeals {
    private String Description;
    private int countOfAttractions;
    private int percentageOff;

    public SpecialDeals(String description, int countOfAttractions, int percentageOff) {
        Description = description;
        this.countOfAttractions = countOfAttractions;
        this.percentageOff = percentageOff;
    }

    public int getPercentageOff() {
        return percentageOff;
    }

    public void setPercentageOff(int percentageOff) {
        this.percentageOff = percentageOff;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getCountOfAttractions() {
        return countOfAttractions;
    }

    public void setCountOfAttractions(int countOfAttractions) {
        this.countOfAttractions = countOfAttractions;
    }
}
