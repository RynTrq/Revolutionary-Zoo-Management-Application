import java.util.ArrayList;
import java.util.Scanner;

public class Database_Animals {
    static Scanner scan = new Scanner(System.in);
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String PURPLE = "\u001B[35m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    private static ArrayList<Animal> listOfAnimals = new ArrayList<>();

    //Adding Animal.
    static int AnimalCodeTrack = 600;
    protected static int addToListOfAnimals(String name, String sound, int price){
        if(searchForAnimal(name)==0){
            System.out.println(name+" already exists. Adding "+name+" with other "+name+"s.");
            return -1;
        }
        listOfAnimals.add(new Animal(name,sound,price,AnimalCodeTrack));
        AnimalCodeTrack += 1;
        return AnimalCodeTrack - 1;
    }
    private static int searchForAnimal(String name){
        for(Animal currentAnimal:listOfAnimals){
            if(currentAnimal.getName().equalsIgnoreCase(name)){
                return 0;
            }
        }
        return -1;
    }
    //Done with adding animal.
    //View Animals.
    protected static void viewAnimals(){
        System.out.println("\nAnimals:");
        if(listOfAnimals.isEmpty()){
            System.out.println("There are no Animals as of now.");
        }
        for(Animal currentAnimal:listOfAnimals){
            System.out.println("Animal Code: "+currentAnimal.getCode());
            System.out.println("Animal name: "+currentAnimal.getName());
            System.out.println("Animal sound: "+currentAnimal.getSound());
            System.out.println("Animal price: "+currentAnimal.getPrice());
            System.out.println("------------------------------");
        }
    }
    //Done with view Animals.
    //Modify Animals.
    protected static void modifyAnimal(int inputCode){
        Animal currentAnimal = findAnimal(inputCode);
        if(currentAnimal == null){
            System.out.println(RED+"ERROR!: Given code doesn't exist."+RESET);
        }else{
            while(true){
                System.out.println("What is it that you wan to modify of "+currentAnimal.getName());
                System.out.println("1. Name.\n" +
                        "2. Description.\n" +
                        "3. Price.\n" +
                        "4. Sound.\n" +
                        "5. Exit.");
                System.out.print("Enter your choice: ");
                int givenInput = Integer.parseInt(scan.nextLine());
                if(givenInput == 5){
                    break;
                }else if(givenInput == 1){
                    System.out.print("Enter new name: ");
                    String newName = scan.nextLine();
                    currentAnimal.setName(newName);
                    System.out.println("The name has been updated to "+newName+"!");
                }else if(givenInput == 2){
                    System.out.print("Enter description: ");
                    String newdes = scan.nextLine();
                    currentAnimal.setDescription(newdes);
                    System.out.println("The description has been updated to "+newdes+"!");
                } else if (givenInput==3) {
                    System.out.print("Enter new Price: ");
                    int newPrice = Integer.parseInt(scan.nextLine());
                    currentAnimal.setPrice(newPrice);
                    System.out.println("The price has been updated to "+newPrice+"!");
                } else if (givenInput == 4) {
                    System.out.print("Enter the sound you want to update with: ");
                    String sound = scan.nextLine();
                    currentAnimal.setSound(sound);
                    System.out.println("The sound has been updated to "+sound+"!");
                }else{
                    System.out.println(RED+"ERROR!: Invalid input! TRY AGAIN."+RESET);
                }
            }
        }
    }
    protected static Animal findAnimal(int inputCode){
        for(Animal currentAnimal:listOfAnimals){
            if(currentAnimal.getCode()==inputCode){
                return currentAnimal;
            }
        }
        return null;
    }
    //Dome with modify animal.
    //Remove Animal.
    protected static void removeAnimal(int inputCode){
        Animal currentAnimal = findAnimal(inputCode);
        if(currentAnimal == null){
            System.out.println(RED+"ERROR!: Given Code doesn't exist."+RESET);
        }else{
            listOfAnimals.remove(currentAnimal);
            System.out.println("Animal with Code "+inputCode+" successfully removed!");
        }
    }
    //Done with Remove Animal.
}