public class Ticket {
    private int count;
    private Attraction attraction;

    public Ticket(int count, Attraction attraction) {
        this.count = count;
        this.attraction = attraction;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Attraction getAttraction() {
        return attraction;
    }

    public void setAttraction(Attraction attraction) {
        this.attraction = attraction;
    }
}
