import java.util.ArrayList;
import java.util.Scanner;
public class Admin {
    private static int premiumPrice = 50;
    private static int basicPrice = 25;
    protected static int totalRevenue = 0;

    public static int getPremiumPrice() {
        return premiumPrice;
    }

    public static void setPremiumPrice(int premiumPrice) {
        Admin.premiumPrice = premiumPrice;
    }

    public static int getBasicPrice() {
        return basicPrice;
    }

    public static void setBasicPrice(int basicPrice) {
        Admin.basicPrice = basicPrice;
    }

    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    static String BLUE= "\u001B[34m";
    static Scanner scan = new Scanner(System.in);
    protected static void enter(){
        System.out.print(YELLOW+"\nEnter Admin Username: "+RESET);
        String username = scan.nextLine();
        System.out.print(YELLOW+"Enter Admin Password: "+RESET);
        String password = scan.nextLine();

        if(username.equals("admin")){
            if(password.equals("admin123")){
                System.out.println("\nLogged in as Admin.");
                commands();
            }else{
                System.out.println("\n"+RED +"Error!: Wrong passsword typed.\n"+RESET);
            }
        }else{
            System.out.println("\n"+RED +"Error!: INVALID username typed."+RESET);
        }
    }
    private static void commands() {
        while (true) {
            System.out.println(CYAN + "\nAdmin Menu:\n" +
                    "1. Manage Attractions.\n" +
                    "2. Manage Animals.\n" +
                    "3. Schedule Events.\n" +
                    "4. Set Discounts.\n" +
                    "5. Set Special Deal.\n" +
                    "6. View Visitor Stats.\n" +
                    "7. View Feedback.\n" +
                    "8. Exit.\n" + RESET);

            System.out.print("Enter your choice: ");
            int givenInput = Integer.parseInt(scan.nextLine());
            if(givenInput==8){
                System.out.println("\nLogged out.");
                break;
            }else if(givenInput==1){
                Admin_ManageAttraction.manageAttractions();
            }else if(givenInput==2){
                Admin_ManageAnimals.manageAnimals();
            }else if(givenInput==3){
                System.out.println("Schedule events:");
                System.out.print("Enter the ID of event you want to schedule:");
                int inputID = Integer.parseInt(scan.nextLine());
                Database_Attractions.scheduleEvent(inputID);
            }else if(givenInput==7){
                System.out.println("\nFeedbacks:");
                Database_Feedback.viewFeedbacks();
            }else if(givenInput==4){
                System.out.println("\nSet Discounts:");
                while(true){
                    System.out.println("\n1. Add discount." +
                            "2. Remove discount\n" +
                            "3. View Discounts\n" +
                            "4. Exit");
                    System.out.print("Enter your choice: ");
                    int anotherinp = Integer.parseInt(scan.nextLine());
                    if(anotherinp==4){
                        break;
                    }else if(anotherinp==1){
                        Database_discounts.addDiscount();
                    }else if(anotherinp==2){
                        Database_discounts.removeDiscount();
                    }else if(anotherinp==3){
                        Database_discounts.viewDiscounts();
                    }else{
                        System.out.println(RED+"ERROR!: Invalid input."+RESET);
                    }
                }
            }else if(givenInput==6){
                ArrayList<Attraction> temp = Database_Attractions.mostPopularAttraction();
                if(temp==null){
                    System.out.println("\nVisitor Statistics:" +
                            "Total Visitors: " + Database_Visitors.listOfVisitors.size() + "\n" +
                            "Total Revenue: " + totalRevenue);
                }else{
                    System.out.println("\nVisitor Statistics:" +
                            "Total Visitors: " + Database_Visitors.listOfVisitors.size() + "\n" +
                            "Total Revenue: " + totalRevenue+"\n" +
                            "Most Popular Attractions:\n");
                    for(Attraction itr:temp){
                        System.out.println(itr.getName());
                    }
                }
            }else if(givenInput==5){
                System.out.println("\nSet Special Deals:");
                while(true){
                    System.out.println("""

                            1. Add special deal.2. Remove special deal
                            3. View special deals
                            4. Exit.""");
                    System.out.print("Enter your choice: ");
                    int anotherinp = Integer.parseInt(scan.nextLine());
                    if(anotherinp==4){
                        break;
                    }else if(anotherinp==1){
                        Database_SpecialDeals.addSpecialDeal();
                    }else if(anotherinp==2){
                        Database_SpecialDeals.removeSpecialDeal();
                    }else if(anotherinp==3){
                        Database_SpecialDeals.viewSpecialDeals();
                    }else{
                        System.out.println(RED+"ERROR!: Invalid input."+RESET);
                    }
                }
            }
        }
    }


}
