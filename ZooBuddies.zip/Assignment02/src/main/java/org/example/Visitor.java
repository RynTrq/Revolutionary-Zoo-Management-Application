import java.util.Scanner;

public class Visitor {
    protected static VisitorClass currentVisitor;
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String PURPLE = "\u001B[35m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    static Scanner scan = new Scanner(System.in);

    protected static void enter(){
        System.out.println("\n1. Register\n" +
                "2. Login\n");
        System.out.print("Enter your choice: ");
        int givenInput = Integer.parseInt(scan.nextLine());
        if(givenInput==1){
            System.out.println("\nRegistration:");
            System.out.print("Enter Visitor Name: ");
            String name = scan.nextLine();
            System.out.print("Enter Visitor Age: ");
            int age = Integer.parseInt(scan.nextLine());
            System.out.print("Enter Visitor Phone Number: ");
            String phNo = scan.nextLine();
            System.out.print("Enter Visitor Balance: ");
            int balance = Integer.parseInt(scan.nextLine());
            System.out.print("Enter Visitor Email: ");
            String Email = scan.nextLine();
            System.out.print("Enter Visitor Password: ");
            String password = scan.nextLine();
            int temp = Database_Visitors.addVisitor(name,age,phNo,balance,Email,password);
            if(temp==-1){
                currentVisitor = Database_Visitors.findVisitor(Email);
                System.out.println("\nRegistration successful.");
                commands();
            }else if(temp==0){
                System.out.println(RED+"ERROR!: The given Email and Phone Number are already registered!"+RESET);
            }else if(temp==1){
                System.out.println(RED+"ERROR!: The given Email is already registered!"+RESET);
            }else if(temp==2){
                System.out.println(RED+"ERROR!: The given Phone Number is already registered!"+RESET);
            }
        }else if(givenInput==2){
            System.out.println("\nLogin:");
            System.out.print("Enter Email: ");
            String Email = scan.nextLine();
            System.out.print("Enter password: ");
            String password = scan.nextLine();
            VisitorClass temp = Database_Visitors.findVisitor(Email);
            if(temp==null){
                System.out.println(RED+"ERROR!: The entered Email doesn't exist!"+RESET);
            }else if(!(temp.getPassword().equals(password))){
                System.out.println(RED+"ERROR!: Wrong password!"+RESET);
            }else{
                currentVisitor = temp;
                System.out.println("\nLogin Successful.");
                commands();
            }
        }else{
            System.out.println(RED+"ERROR!: Invalid input!"+RESET);
        }
    }
    private static void commands(){
        while(true){
            System.out.println("\nVisitor Menu:");
            System.out.println("1. Explore the Zoo.\n" +
                    "2. Buy Membership.\n" +
                    "3. Buy Tickets.\n" +
                    "4. View Discounts.\n" +
                    "5. View Special Deals.\n" +
                    "6. Visit Animals.\n" +
                    "7. Visit Attractions.\n" +
                    "8. Leave Feedback.\n" +
                    "9. Log Out.");

            System.out.print("Enter your choice: ");
            int givenInput = Integer.parseInt(scan.nextLine());

            if(givenInput==9){
                currentVisitor = null;
                System.out.println("\nLogged out.");
                break;
            }else if(givenInput==2){
                System.out.println("\nEnter experience level(Basic/Premium) you want to update to: ");
                String experience = scan.nextLine();
                String discountCode = null;
                while(true) {
                    System.out.print("Do you have a discount code(Y/N): ");
                    String ifDiscount = scan.nextLine();
                    if (ifDiscount.equalsIgnoreCase("Y")) {
                        System.out.print("Enter discount code: ");
                        discountCode = scan.nextLine();
                        break;
                    } else if (ifDiscount.equalsIgnoreCase("N")) {
                        discountCode = null;
                        break;
                    } else {
                        System.out.println(RED + "ERROR!: Invalid Input!" + RESET);
                    }
                }
                if(discountCode!=null){
                    int eligibility = Database_discounts.checkEligibility(discountCode);
                    if(eligibility==1){
                        if(experience.equalsIgnoreCase("Basic") || experience.equalsIgnoreCase("Premium")){
                            System.out.println("Discount code Applied!");
                            Database_Visitors.buyMembership(currentVisitor,experience,Database_discounts.findDiscount(discountCode).getDiscountPercentage());
                        }else{
                            System.out.println(RED+"Invalid input for membership experience."+RESET);
                        }
                    }else if(eligibility==-1){
                        System.out.println("Given discount code doesn't exist.");
                    }else if(eligibility==0){
                        System.out.println("You are not eligible for this discount code.");
                    }
                }else{
                    if(experience.equalsIgnoreCase("Basic") || experience.equalsIgnoreCase("Premium")){
                        Database_Visitors.buyMembership(currentVisitor,experience,0);
                    }else{
                        System.out.println(RED+"Invalid input for membership experience"+RESET);
                    }
                }
            }else if(givenInput==3){
                System.out.println("\nBuy tickets:");
                System.out.print("Enter the ID of attraction you want to purchase - ");
                int ID = Integer.parseInt(scan.nextLine());
                System.out.print("Enter the number of tickets you want to purchase - ");
                int count = Integer.parseInt(scan.nextLine());
                String discountCode = null;
                while(true) {
                    System.out.print("Do you have a discount code(Y/N): ");
                    String ifDiscount = scan.nextLine();
                    if (ifDiscount.equalsIgnoreCase("Y")) {
                        System.out.print("Enter discount code: ");
                        discountCode = scan.nextLine();
                        break;
                    } else if (ifDiscount.equalsIgnoreCase("N")) {
                        discountCode = null;
                        break;
                    } else {
                        System.out.println(RED + "ERROR!: Invalid Input!" + RESET);
                    }
                }
                if(discountCode!=null){
                    int eligibility = Database_discounts.checkEligibility(discountCode);
                    if(eligibility==1){
                        System.out.println("Discount code Applied!");
                        Database_Attractions.buyTickets(ID,count,Database_discounts.findDiscount(discountCode).getDiscountPercentage());
                    }else if(eligibility==-1){
                        System.out.println("Given discount code doesn't exist.");
                    }else if(eligibility==0){
                        System.out.println("You are not eligible for this discount code.");
                    }
                }else{
                    Database_Attractions.buyTickets(ID,count,0);
                }
            }else if(givenInput==6){
                System.out.println("\nVisit animal: ");
                System.out.print("Enter the code of Animal you want to visit: ");
                int inputCode = Integer.parseInt(scan.nextLine());
                Animal temp = Database_Animals.findAnimal(inputCode);
                if(currentVisitor.getExperience().equalsIgnoreCase("Basic") || currentVisitor.getExperience().equalsIgnoreCase("Premium")){
                    visitAnimal(temp);
                }else{
                    int newBalance = currentVisitor.getBalance() - temp.getPrice();
                    if(newBalance>=0){
                        System.out.println("Visiting "+temp.getName()+":");
                        currentVisitor.setBalance(newBalance);
                        Admin.totalRevenue += temp.getPrice();
                        System.out.println("Current Balance - "+currentVisitor.getBalance());
                        visitAnimal(temp);
                    }else{
                        System.out.println("You ain't got enough balance or any experience level to visit "+temp.getName()+".");
                    }
                }
            }else if(givenInput==7){
                System.out.print("\nEnter the ID of attraction you want to visit: ");
                int inputID = Integer.parseInt(scan.nextLine());
                Database_Attractions.visitAttraction(inputID);
            }else if(givenInput == 8){
                System.out.println("\nFeedback:");
                System.out.print("Give your feedback in 200 characters: ");
                String content = scan.nextLine();
                if(content.length()>200){
                    System.out.println(RED+"ERROR!: You've exceeded the limit of characters."+RESET);
                }else{
                    Database_Feedback.newFeedback(currentVisitor.getName(),content);
                }
            }else if(givenInput==4){
                Database_discounts.viewDiscounts();
            }else if(givenInput==1){
                while(true){
                    System.out.println("\nExplore the zoo:");
                    System.out.println("1. View Attractions.\n" +
                            "2. View Animals.\n" +
                            "3. Exit");
                    int inp = Integer.parseInt(scan.nextLine());
                    if(inp==3){
                        break;
                    }else if(inp==1){
                        System.out.println("View Attractions:");
                        Database_Attractions.viewAttractions();
                    }else if(inp==2){
                        System.out.println("View Animals:");
                        Database_Animals.viewAnimals();
                    }else{
                        System.out.println(RED+"ERROR!: Invalid Input."+RESET);
                    }
                }
            }else if(givenInput==5){
                Database_SpecialDeals.viewSpecialDeals();
            }else{
                System.out.println(RED+"ERROR!: Invalid Input."+RESET);
            }
        }
    }

    private static void visitAnimal(Animal temp){
        if(temp==null){
            System.out.println("The given code of animal doesn't exist");
        }else{
            System.out.print("Choose(feed or read) for "+temp.getName()+".: ");
            String inputGiven = scan.nextLine();
            if(inputGiven.equalsIgnoreCase("feed")){
                System.out.println(temp.getSound());
            }else if(inputGiven.equalsIgnoreCase("read")){
                if(temp.getDescription()==null){
                    System.out.println("Sorry, description about "+temp.getName()+" hasn't been updated.");
                }else{
                    System.out.println(temp.getDescription());
                }
            }
        }
    }
}
