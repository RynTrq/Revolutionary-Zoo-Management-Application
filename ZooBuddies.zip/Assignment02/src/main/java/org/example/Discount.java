public class Discount {
    private String discountCode;
    private String details;
    private int startAge;
    private int endAge;
    private int discountPercentage;

    public Discount(String discountCode, String details, int startAge, int endAge,int discountPercentage) {
        this.discountCode = discountCode;
        this.details = details;
        this.startAge = startAge;
        this.endAge = endAge;
        this.discountPercentage = discountPercentage;
    }

    public int getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(int discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public int getStartAge() {
        return startAge;
    }

    public void setStartAge(int startAge) {
        this.startAge = startAge;
    }

    public int getEndAge() {
        return endAge;
    }

    public void setEndAge(int endAge) {
        this.endAge = endAge;
    }
}
