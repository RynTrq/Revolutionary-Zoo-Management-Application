import java.util.Scanner;

public class Admin_ManageAttraction {
    static String RESET = "\u001B[0m";
    static String YELLOW = "\u001B[33m";
    static String CYAN = "\u001B[36m";
    static String RED = "\u001B[31m";
    static String BLUE= "\u001B[34m";

    static Scanner scan = new Scanner(System.in);
    protected static void manageAttractions() {
        while(true) {
            System.out.println(BLUE + "\nManage Attractions" + RESET);
            System.out.println(BLUE + "\n1. Add Attraction.\n" +
                    "2. View Attractions.\n" +
                    "3. Modify Attraction.\n" +
                    "4. Remove Attraction.\n" +
                    "5. Exit.\n" + RESET);
            System.out.print("Enter your choice: ");
            int givenInput = Integer.parseInt(scan.nextLine());
            if (givenInput == 5) {
                break;
            }else if(givenInput == 1){
                addAttraction();
            }else if(givenInput == 2){
                viewAttractions();
            }else if(givenInput == 3){
                modifyAttraction();
            }else if(givenInput == 4){
                removeAttraction();
            }else{
                System.out.println(RED+"ERROR!: Invalid input!"+RESET);
            }
        }
    }


    private static void addAttraction(){
        System.out.print("\nEnter Attractoin name: ");
        String name = scan.nextLine();
        System.out.print("Enter Attraction Description: ");
        String description = scan.nextLine();
        System.out.print("Enter price of Attraction(in Rs): ");
        int price = Integer.parseInt(scan.nextLine());

        int ID = Database_Attractions.addToListOfAttractions(name,description,price);

        if(ID!=-1){
            System.out.println("Attraction added successfully\n" +
                    "Attraction ID - "+ID);
        }
    }

    private static void viewAttractions(){
        Database_Attractions.viewAttractions();
    }
    private static void modifyAttraction(){
        System.out.println("\nModify Attraction.");
        System.out.print("Enter the ID of attraction you want to modify: ");
        int inputID = Integer.parseInt(scan.nextLine());

        Database_Attractions.modifyAttraction(inputID);
    }
    private static void removeAttraction(){
        System.out.println("Remove Attraction:");
        System.out.print("Enter ID of Attraction you want to remove: ");
        int inputID = Integer.parseInt(scan.nextLine());
        Database_Attractions.removeAttraction(inputID);
    }
}
