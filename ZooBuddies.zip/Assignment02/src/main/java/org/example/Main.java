import java.util.*;
public class Main {
    public static void main(String[] args) {
        String RESET = "\u001B[0m";
        String YELLOW = "\u001B[33m";
        String PURPLE = "\u001B[35m";
        String CYAN = "\u001B[36m";
        String RED = "\u001B[31m";
        Scanner scan = new Scanner(System.in);
        System.out.println(PURPLE+"Welcome to ZOOtopia!"+RESET);
        while(true){
            System.out.println(PURPLE+"\n1. Enter as Admin.\n" +
                    "2. Enter as a Visitor.\n" +
                    "3.View Special Deals.\n"+RESET);
            System.out.print("Enter your choice: ");
            int givenInput = Integer.parseInt(scan.nextLine());
            switch (givenInput){
                case 1:
                    Admin.enter();
                    break;
                case 2:
                    Visitor.enter();
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid input given. Try again!");
            }
        }
    }
}